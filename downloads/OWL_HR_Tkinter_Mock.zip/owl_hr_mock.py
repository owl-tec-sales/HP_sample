import csv
import tkinter as tk
from datetime import date
from tkinter import filedialog, messagebox, ttk


COLORS = {
    "navy": "#0B2242",
    "blue": "#1769E0",
    "blue_hover": "#0F58C2",
    "blue_pale": "#EAF2FF",
    "bg": "#F4F7FB",
    "card": "#FFFFFF",
    "text": "#172033",
    "subtext": "#667085",
    "line": "#E3E8EF",
    "green": "#1E9E6A",
    "green_pale": "#E8F7F1",
    "orange": "#E8872E",
    "orange_pale": "#FFF3E5",
    "red": "#D94C4C",
}


EMPLOYEES = [
    ("EMP-001", "佐藤 直樹", "さとう なおき", "営業部", "部長", "正社員", "在籍", "2020/04/01", "naoki.sato@owl-tech.jp", "03-1234-1001"),
    ("EMP-002", "鈴木 美咲", "すずき みさき", "総務部", "主任", "正社員", "在籍", "2021/06/15", "misaki.suzuki@owl-tech.jp", "03-1234-1002"),
    ("EMP-003", "高橋 健太", "たかはし けんた", "開発部", "リーダー", "正社員", "在籍", "2019/10/01", "kenta.takahashi@owl-tech.jp", "03-1234-1003"),
    ("EMP-004", "田中 彩香", "たなか あやか", "営業部", "メンバー", "正社員", "在籍", "2023/04/01", "ayaka.tanaka@owl-tech.jp", "03-1234-1004"),
    ("EMP-005", "伊藤 大輔", "いとう だいすけ", "開発部", "メンバー", "契約社員", "在籍", "2022/11/01", "daisuke.ito@owl-tech.jp", "03-1234-1005"),
    ("EMP-006", "渡辺 由衣", "わたなべ ゆい", "企画部", "マネージャー", "正社員", "在籍", "2018/08/20", "yui.watanabe@owl-tech.jp", "03-1234-1006"),
    ("EMP-007", "山本 翔太", "やまもと しょうた", "開発部", "メンバー", "正社員", "休職", "2022/04/01", "shota.yamamoto@owl-tech.jp", "03-1234-1007"),
    ("EMP-008", "中村 真央", "なかむら まお", "総務部", "メンバー", "パート", "在籍", "2024/02/01", "mao.nakamura@owl-tech.jp", "03-1234-1008"),
    ("EMP-009", "小林 拓海", "こばやし たくみ", "営業部", "メンバー", "正社員", "退職予定", "2021/09/01", "takumi.kobayashi@owl-tech.jp", "03-1234-1009"),
    ("EMP-010", "加藤 千尋", "かとう ちひろ", "企画部", "メンバー", "正社員", "在籍", "2023/07/10", "chihiro.kato@owl-tech.jp", "03-1234-1010"),
    ("EMP-011", "吉田 悠斗", "よしだ ゆうと", "開発部", "メンバー", "業務委託", "在籍", "2024/05/01", "yuto.yoshida@owl-tech.jp", "03-1234-1011"),
    ("EMP-012", "山田 玲奈", "やまだ れな", "営業部", "メンバー", "正社員", "在籍", "2024/04/01", "rena.yamada@owl-tech.jp", "03-1234-1012"),
]


class OwlHRMock(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OWL HR | 従業員管理システム")
        self.geometry("1440x880")
        self.minsize(1180, 720)
        self.configure(bg=COLORS["bg"])
        self.option_add("*Font", ("Yu Gothic UI", 10))
        self.active_menu = None
        self.menu_widgets = {}
        self.search_var = tk.StringVar()
        self.department_var = tk.StringVar(value="すべての部署")
        self.status_var = tk.StringVar(value="すべての在籍状況")
        self.build_styles()
        self.build_layout()
        self.show_dashboard()

    def build_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", background=COLORS["card"], foreground=COLORS["text"], rowheight=44,
                        fieldbackground=COLORS["card"], borderwidth=0, font=("Yu Gothic UI", 10))
        style.configure("Treeview.Heading", background="#F8FAFC", foreground=COLORS["subtext"], relief="flat",
                        font=("Yu Gothic UI", 9, "bold"), padding=(10, 12))
        style.map("Treeview", background=[("selected", COLORS["blue_pale"])], foreground=[("selected", COLORS["text"])])
        style.map("Treeview.Heading", background=[("active", "#F1F5F9")])
        style.configure("TCombobox", padding=8, fieldbackground="white", background="white", bordercolor=COLORS["line"])

    def build_layout(self):
        self.sidebar = tk.Frame(self, bg=COLORS["navy"], width=238)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        logo = tk.Frame(self.sidebar, bg=COLORS["navy"], height=92)
        logo.pack(fill="x")
        logo.pack_propagate(False)
        tk.Label(logo, text="O", bg=COLORS["blue"], fg="white", width=2, height=1,
                 font=("Segoe UI", 17, "bold")).pack(side="left", padx=(22, 12), pady=26)
        logo_text = tk.Frame(logo, bg=COLORS["navy"])
        logo_text.pack(side="left", pady=25)
        tk.Label(logo_text, text="OWL HR", bg=COLORS["navy"], fg="white",
                 font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tk.Label(logo_text, text="EMPLOYEE MANAGEMENT", bg=COLORS["navy"], fg="#8295AF",
                 font=("Segoe UI", 6, "bold")).pack(anchor="w")

        tk.Label(self.sidebar, text="MAIN MENU", bg=COLORS["navy"], fg="#71849F",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=24, pady=(20, 8))
        for key, icon, label, command in [
            ("dashboard", "▦", "ダッシュボード", self.show_dashboard),
            ("employees", "●", "従業員一覧", self.show_employees),
            ("history", "◷", "変更履歴", self.show_history),
            ("reports", "▤", "レポート", self.show_reports),
        ]:
            row = tk.Frame(self.sidebar, bg=COLORS["navy"], cursor="hand2", height=48)
            row.pack(fill="x", padx=10, pady=2)
            row.pack_propagate(False)
            icon_label = tk.Label(row, text=icon, bg=COLORS["navy"], fg="#AAB8CA", font=("Segoe UI Symbol", 13))
            icon_label.pack(side="left", padx=(16, 14))
            text_label = tk.Label(row, text=label, bg=COLORS["navy"], fg="#CDD6E2", font=("Yu Gothic UI", 10))
            text_label.pack(side="left")
            for widget in (row, icon_label, text_label):
                widget.bind("<Button-1>", lambda _e, c=command: c())
            self.menu_widgets[key] = (row, icon_label, text_label)

        bottom = tk.Frame(self.sidebar, bg="#091C36")
        bottom.pack(side="bottom", fill="x")
        tk.Label(bottom, text="A", bg="#DCEBFF", fg=COLORS["blue"], width=3, height=2,
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=(18, 10), pady=16)
        user = tk.Frame(bottom, bg="#091C36")
        user.pack(side="left", pady=14)
        tk.Label(user, text="管理者", bg="#091C36", fg="white", font=("Yu Gothic UI", 9, "bold")).pack(anchor="w")
        tk.Label(user, text="admin@owl-tech.jp", bg="#091C36", fg="#8295AF", font=("Segoe UI", 7)).pack(anchor="w")

        self.main = tk.Frame(self, bg=COLORS["bg"])
        self.main.pack(side="left", fill="both", expand=True)

        header = tk.Frame(self.main, bg="white", height=72, highlightbackground=COLORS["line"], highlightthickness=1)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="OWL Technology", bg="white", fg=COLORS["subtext"],
                 font=("Segoe UI", 9)).pack(side="left", padx=28)
        tk.Button(header, text="?", bg="#F1F5F9", fg=COLORS["subtext"], relief="flat", width=3,
                  font=("Segoe UI", 10, "bold"), command=lambda: messagebox.showinfo("ヘルプ", "OWL HR デモ画面です。\n表示されている情報はサンプルです。")).pack(side="right", padx=(0, 28), pady=19)
        tk.Label(header, text=date.today().strftime("%Y年%m月%d日"), bg="white", fg=COLORS["subtext"],
                 font=("Yu Gothic UI", 9)).pack(side="right", padx=18)

        self.content = tk.Frame(self.main, bg=COLORS["bg"])
        self.content.pack(fill="both", expand=True)

    def set_active_menu(self, key):
        self.active_menu = key
        for name, (row, icon, label) in self.menu_widgets.items():
            active = name == key
            bg = "#12345F" if active else COLORS["navy"]
            row.configure(bg=bg)
            icon.configure(bg=bg, fg="#6EAAFF" if active else "#AAB8CA")
            label.configure(bg=bg, fg="white" if active else "#CDD6E2", font=("Yu Gothic UI", 10, "bold" if active else "normal"))

    def clear_content(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    def page_heading(self, title, subtitle, action_text=None, action=None):
        frame = tk.Frame(self.content, bg=COLORS["bg"])
        frame.pack(fill="x", padx=32, pady=(28, 20))
        left = tk.Frame(frame, bg=COLORS["bg"])
        left.pack(side="left")
        tk.Label(left, text=title, bg=COLORS["bg"], fg=COLORS["text"], font=("Yu Gothic UI", 22, "bold")).pack(anchor="w")
        tk.Label(left, text=subtitle, bg=COLORS["bg"], fg=COLORS["subtext"], font=("Yu Gothic UI", 9)).pack(anchor="w", pady=(4, 0))
        if action_text:
            self.primary_button(frame, action_text, action).pack(side="right", pady=8)

    def primary_button(self, parent, text, command):
        return tk.Button(parent, text=text, command=command, bg=COLORS["blue"], fg="white", activebackground=COLORS["blue_hover"],
                         activeforeground="white", relief="flat", padx=18, pady=10, cursor="hand2", font=("Yu Gothic UI", 9, "bold"))

    def show_dashboard(self):
        self.clear_content()
        self.set_active_menu("dashboard")
        self.page_heading("ダッシュボード", "従業員情報と組織状況のサマリー", "＋  従業員を登録", self.open_add_dialog)

        stats = tk.Frame(self.content, bg=COLORS["bg"])
        stats.pack(fill="x", padx=32)
        cards = [
            ("従業員数", "48", "名", "前月比  +2", COLORS["blue"], COLORS["blue_pale"]),
            ("今月の入社", "3", "名", "入社予定を含む", COLORS["green"], COLORS["green_pale"]),
            ("休職者", "1", "名", "前月から変更なし", COLORS["orange"], COLORS["orange_pale"]),
            ("未入力項目", "7", "件", "確認が必要です", COLORS["red"], "#FDECEC"),
        ]
        for i, data in enumerate(cards):
            stats.grid_columnconfigure(i, weight=1)
            self.stat_card(stats, *data).grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 7, 0 if i == 3 else 7))

        lower = tk.Frame(self.content, bg=COLORS["bg"])
        lower.pack(fill="both", expand=True, padx=32, pady=22)
        lower.grid_columnconfigure(0, weight=3)
        lower.grid_columnconfigure(1, weight=2)
        lower.grid_rowconfigure(0, weight=1)

        dept = self.card_frame(lower)
        dept.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.card_title(dept, "部署別従業員数", "2026年7月現在")
        chart = tk.Frame(dept, bg="white")
        chart.pack(fill="both", expand=True, padx=24, pady=(10, 24))
        for name, value, color in [("営業部", 14, "#1769E0"), ("開発部", 18, "#4A8EF0"), ("総務部", 7, "#76A9F4"), ("企画部", 9, "#A3C5F7")]:
            row = tk.Frame(chart, bg="white")
            row.pack(fill="x", pady=9)
            tk.Label(row, text=name, width=8, anchor="w", bg="white", fg=COLORS["text"], font=("Yu Gothic UI", 9)).pack(side="left")
            bar_bg = tk.Frame(row, bg="#EEF2F7", height=12)
            bar_bg.pack(side="left", fill="x", expand=True, padx=12)
            bar_bg.pack_propagate(False)
            tk.Frame(bar_bg, bg=color, width=value * 14).pack(side="left", fill="y")
            tk.Label(row, text=f"{value}名", width=5, anchor="e", bg="white", fg=COLORS["subtext"], font=("Yu Gothic UI", 9, "bold")).pack(side="right")

        notices = self.card_frame(lower)
        notices.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        self.card_title(notices, "お知らせ", "すべて見る  ›")
        items = [
            ("本日", "社員情報の定期確認をお願いします", "総務部からのお知らせ"),
            ("7/15", "8月入社予定者を登録しました", "人事担当者"),
            ("7/10", "組織図を更新しました", "システム管理者"),
            ("7/01", "CSV出力項目を追加しました", "システム管理者"),
        ]
        for day, title, detail in items:
            row = tk.Frame(notices, bg="white")
            row.pack(fill="x", padx=22, pady=8)
            tk.Label(row, text=day, bg=COLORS["blue_pale"], fg=COLORS["blue"], width=7, pady=5,
                     font=("Yu Gothic UI", 8, "bold")).pack(side="left", anchor="n")
            body = tk.Frame(row, bg="white")
            body.pack(side="left", fill="x", expand=True, padx=12)
            tk.Label(body, text=title, bg="white", fg=COLORS["text"], anchor="w", font=("Yu Gothic UI", 9, "bold")).pack(fill="x")
            tk.Label(body, text=detail, bg="white", fg=COLORS["subtext"], anchor="w", font=("Yu Gothic UI", 8)).pack(fill="x", pady=(3, 0))

    def stat_card(self, parent, title, value, unit, note, accent, pale):
        card = tk.Frame(parent, bg="white", highlightbackground=COLORS["line"], highlightthickness=1, height=130)
        card.pack_propagate(False)
        top = tk.Frame(card, bg="white")
        top.pack(fill="x", padx=18, pady=(17, 4))
        tk.Label(top, text=title, bg="white", fg=COLORS["subtext"], font=("Yu Gothic UI", 9)).pack(side="left")
        tk.Label(top, text="●", bg=pale, fg=accent, width=3, height=1, font=("Segoe UI", 8)).pack(side="right")
        value_row = tk.Frame(card, bg="white")
        value_row.pack(fill="x", padx=18)
        tk.Label(value_row, text=value, bg="white", fg=COLORS["text"], font=("Segoe UI", 25, "bold")).pack(side="left")
        tk.Label(value_row, text=unit, bg="white", fg=COLORS["subtext"], font=("Yu Gothic UI", 9)).pack(side="left", padx=5, pady=(12, 0))
        tk.Label(card, text=note, bg="white", fg=accent, font=("Yu Gothic UI", 8)).pack(anchor="w", padx=18)
        return card

    def card_frame(self, parent):
        return tk.Frame(parent, bg="white", highlightbackground=COLORS["line"], highlightthickness=1)

    def card_title(self, parent, title, right):
        row = tk.Frame(parent, bg="white")
        row.pack(fill="x", padx=22, pady=(19, 14))
        tk.Label(row, text=title, bg="white", fg=COLORS["text"], font=("Yu Gothic UI", 11, "bold")).pack(side="left")
        tk.Label(row, text=right, bg="white", fg=COLORS["blue"] if "›" in right else COLORS["subtext"], font=("Yu Gothic UI", 8)).pack(side="right")

    def show_employees(self):
        self.clear_content()
        self.set_active_menu("employees")
        self.page_heading("従業員一覧", "登録されている従業員情報の検索・閲覧・出力", "＋  従業員を登録", self.open_add_dialog)

        filters = self.card_frame(self.content)
        filters.pack(fill="x", padx=32, pady=(0, 16))
        search_wrap = tk.Frame(filters, bg="white")
        search_wrap.pack(side="left", padx=18, pady=14)
        tk.Label(search_wrap, text="検索", bg="white", fg=COLORS["subtext"], font=("Yu Gothic UI", 8, "bold")).pack(anchor="w")
        search = tk.Entry(search_wrap, textvariable=self.search_var, width=28, relief="solid", bd=1,
                          highlightcolor=COLORS["blue"], highlightbackground=COLORS["line"], font=("Yu Gothic UI", 10))
        search.pack(ipady=7, pady=(4, 0))
        search.bind("<KeyRelease>", lambda _e: self.filter_employees())
        self.filter_combo(filters, "部署", self.department_var, ["すべての部署", "営業部", "開発部", "総務部", "企画部"])
        self.filter_combo(filters, "在籍状況", self.status_var, ["すべての在籍状況", "在籍", "休職", "退職予定"])
        tk.Button(filters, text="条件をクリア", command=self.clear_filters, bg="white", fg=COLORS["blue"], relief="flat",
                  cursor="hand2", font=("Yu Gothic UI", 8, "bold")).pack(side="left", padx=14, pady=(22, 0))

        table_card = self.card_frame(self.content)
        table_card.pack(fill="both", expand=True, padx=32, pady=(0, 28))
        table_top = tk.Frame(table_card, bg="white")
        table_top.pack(fill="x", padx=18, pady=14)
        self.result_label = tk.Label(table_top, text="12件の従業員", bg="white", fg=COLORS["text"], font=("Yu Gothic UI", 10, "bold"))
        self.result_label.pack(side="left")
        tk.Button(table_top, text="CSV出力", command=self.export_csv, bg="white", fg=COLORS["text"], relief="solid", bd=1,
                  padx=13, pady=6, cursor="hand2", font=("Yu Gothic UI", 8, "bold")).pack(side="right")

        columns = ("id", "name", "dept", "position", "type", "status", "joined")
        self.tree = ttk.Treeview(table_card, columns=columns, show="headings", selectmode="browse")
        headings = {"id": "社員番号", "name": "氏名", "dept": "部署", "position": "役職", "type": "雇用形態", "status": "在籍状況", "joined": "入社日"}
        widths = {"id": 90, "name": 150, "dept": 105, "position": 105, "type": 105, "status": 90, "joined": 110}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="w", stretch=True)
        scroll = ttk.Scrollbar(table_card, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y", pady=(0, 12))
        self.tree.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self.tree.bind("<Double-1>", self.open_selected_employee)
        self.tree.bind("<Return>", self.open_selected_employee)
        self.filter_employees()

    def filter_combo(self, parent, label, variable, values):
        wrap = tk.Frame(parent, bg="white")
        wrap.pack(side="left", padx=8, pady=14)
        tk.Label(wrap, text=label, bg="white", fg=COLORS["subtext"], font=("Yu Gothic UI", 8, "bold")).pack(anchor="w")
        combo = ttk.Combobox(wrap, textvariable=variable, values=values, state="readonly", width=17)
        combo.pack(pady=(4, 0))
        combo.bind("<<ComboboxSelected>>", lambda _e: self.filter_employees())

    def clear_filters(self):
        self.search_var.set("")
        self.department_var.set("すべての部署")
        self.status_var.set("すべての在籍状況")
        self.filter_employees()

    def filtered_data(self):
        query = self.search_var.get().strip().lower()
        dept = self.department_var.get()
        status = self.status_var.get()
        return [e for e in EMPLOYEES if
                (not query or query in " ".join(e).lower()) and
                (dept == "すべての部署" or e[3] == dept) and
                (status == "すべての在籍状況" or e[6] == status)]

    def filter_employees(self):
        if not hasattr(self, "tree"):
            return
        self.tree.delete(*self.tree.get_children())
        rows = self.filtered_data()
        for employee in rows:
            self.tree.insert("", "end", iid=employee[0], values=(employee[0], employee[1], employee[3], employee[4], employee[5], employee[6], employee[7]))
        self.result_label.configure(text=f"{len(rows)}件の従業員")

    def open_selected_employee(self, _event=None):
        selection = self.tree.selection()
        if selection:
            employee = next(e for e in EMPLOYEES if e[0] == selection[0])
            self.employee_dialog(employee)

    def employee_dialog(self, employee):
        dialog = tk.Toplevel(self)
        dialog.title(f"従業員詳細 | {employee[1]}")
        dialog.geometry("720x610")
        dialog.resizable(False, False)
        dialog.configure(bg=COLORS["bg"])
        dialog.transient(self)
        dialog.grab_set()

        top = tk.Frame(dialog, bg=COLORS["navy"], height=112)
        top.pack(fill="x")
        top.pack_propagate(False)
        avatar = tk.Label(top, text=employee[1].replace(" ", "")[:1], bg=COLORS["blue"], fg="white", width=3, height=2,
                          font=("Yu Gothic UI", 17, "bold"))
        avatar.pack(side="left", padx=(30, 17), pady=25)
        name_frame = tk.Frame(top, bg=COLORS["navy"])
        name_frame.pack(side="left", pady=24)
        tk.Label(name_frame, text=employee[1], bg=COLORS["navy"], fg="white", font=("Yu Gothic UI", 18, "bold")).pack(anchor="w")
        tk.Label(name_frame, text=f"{employee[0]}  /  {employee[2]}", bg=COLORS["navy"], fg="#AFC0D5", font=("Yu Gothic UI", 8)).pack(anchor="w", pady=(4, 0))
        tk.Label(top, text=employee[6], bg=COLORS["green_pale"] if employee[6] == "在籍" else COLORS["orange_pale"],
                 fg=COLORS["green"] if employee[6] == "在籍" else COLORS["orange"], padx=12, pady=5,
                 font=("Yu Gothic UI", 8, "bold")).pack(side="right", padx=28)

        body = tk.Frame(dialog, bg="white", highlightbackground=COLORS["line"], highlightthickness=1)
        body.pack(fill="both", expand=True, padx=28, pady=24)
        tk.Label(body, text="基本情報", bg="white", fg=COLORS["text"], font=("Yu Gothic UI", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=24, pady=(22, 18))
        fields = [("所属部署", employee[3]), ("役職", employee[4]), ("雇用形態", employee[5]), ("入社日", employee[7]),
                  ("メールアドレス", employee[8]), ("電話番号", employee[9])]
        for idx, (label, value) in enumerate(fields, start=1):
            row, col = (idx - 1) // 2 + 1, (idx - 1) % 2
            cell = tk.Frame(body, bg="white")
            cell.grid(row=row, column=col, sticky="nsew", padx=24, pady=13)
            tk.Label(cell, text=label, bg="white", fg=COLORS["subtext"], font=("Yu Gothic UI", 8, "bold")).pack(anchor="w")
            tk.Label(cell, text=value, bg="white", fg=COLORS["text"], font=("Yu Gothic UI", 10)).pack(anchor="w", pady=(6, 0))
        body.grid_columnconfigure(0, weight=1)
        body.grid_columnconfigure(1, weight=1)
        tk.Label(body, text="最終更新：2026/07/15  14:32  ｜  更新者：管理者", bg="#F8FAFC", fg=COLORS["subtext"],
                 anchor="w", padx=16, pady=11, font=("Yu Gothic UI", 8)).grid(row=4, column=0, columnspan=2, sticky="ew", padx=24, pady=(22, 16))

        buttons = tk.Frame(dialog, bg=COLORS["bg"])
        buttons.pack(fill="x", padx=28, pady=(0, 22))
        tk.Button(buttons, text="閉じる", command=dialog.destroy, bg="white", fg=COLORS["text"], relief="solid", bd=1,
                  padx=24, pady=9).pack(side="right", padx=(10, 0))
        tk.Button(buttons, text="編集する", command=lambda: messagebox.showinfo("編集", "デモ画面のため編集内容は保存されません。", parent=dialog),
                  bg=COLORS["blue"], fg="white", relief="flat", padx=24, pady=10, font=("Yu Gothic UI", 9, "bold")).pack(side="right")

    def open_add_dialog(self):
        messagebox.showinfo("従業員登録", "従業員登録フォームを開きます。\n\n※この画面はデモのため、登録は行われません。")

    def export_csv(self):
        path = filedialog.asksaveasfilename(title="CSVを保存", defaultextension=".csv", filetypes=[("CSVファイル", "*.csv")], initialfile="従業員一覧.csv")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as file:
            writer = csv.writer(file)
            writer.writerow(["社員番号", "氏名", "ふりがな", "部署", "役職", "雇用形態", "在籍状況", "入社日", "メール", "電話番号"])
            writer.writerows(self.filtered_data())
        messagebox.showinfo("CSV出力", "従業員一覧をCSV形式で保存しました。")

    def show_history(self):
        self.show_simple_page("history", "変更履歴", "従業員情報の更新履歴", [
            ("2026/07/15 14:32", "鈴木 美咲", "EMP-008 中村 真央", "所属部署を更新", "営業部 → 総務部"),
            ("2026/07/15 10:05", "管理者", "EMP-012 山田 玲奈", "連絡先を更新", "電話番号を変更"),
            ("2026/07/10 16:20", "佐藤 直樹", "EMP-004 田中 彩香", "役職を更新", "メンバー → 主任"),
            ("2026/07/08 09:14", "管理者", "EMP-007 山本 翔太", "在籍状況を更新", "在籍 → 休職"),
        ])

    def show_reports(self):
        self.clear_content()
        self.set_active_menu("reports")
        self.page_heading("レポート", "人員構成をわかりやすく可視化")
        wrap = tk.Frame(self.content, bg=COLORS["bg"])
        wrap.pack(fill="both", expand=True, padx=32, pady=(0, 28))
        for i, (title, value, note, color) in enumerate([
            ("正社員比率", "79%", "38 / 48名", COLORS["blue"]),
            ("平均勤続年数", "4.2年", "前年比 +0.3年", COLORS["green"]),
            ("平均年齢", "36.8歳", "全従業員", COLORS["orange"]),
        ]):
            card = self.card_frame(wrap)
            card.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0 if i == 2 else 8))
            wrap.grid_columnconfigure(i, weight=1)
            tk.Label(card, text=title, bg="white", fg=COLORS["subtext"], font=("Yu Gothic UI", 9)).pack(anchor="w", padx=24, pady=(22, 6))
            tk.Label(card, text=value, bg="white", fg=color, font=("Segoe UI", 27, "bold")).pack(anchor="w", padx=24)
            tk.Label(card, text=note, bg="white", fg=COLORS["subtext"], font=("Yu Gothic UI", 8)).pack(anchor="w", padx=24, pady=(4, 22))

    def show_simple_page(self, menu, title, subtitle, rows):
        self.clear_content()
        self.set_active_menu(menu)
        self.page_heading(title, subtitle)
        card = self.card_frame(self.content)
        card.pack(fill="both", expand=True, padx=32, pady=(0, 28))
        headers = tk.Frame(card, bg="#F8FAFC")
        headers.pack(fill="x", padx=1, pady=(1, 0))
        for text, width in [("日時", 18), ("操作ユーザー", 16), ("対象", 22), ("操作", 18), ("変更内容", 28)]:
            tk.Label(headers, text=text, width=width, anchor="w", bg="#F8FAFC", fg=COLORS["subtext"],
                     padx=12, pady=13, font=("Yu Gothic UI", 8, "bold")).pack(side="left", fill="x", expand=True)
        for row_data in rows:
            row = tk.Frame(card, bg="white", highlightbackground=COLORS["line"], highlightthickness=1)
            row.pack(fill="x", padx=1)
            for text, width in zip(row_data, (18, 16, 22, 18, 28)):
                tk.Label(row, text=text, width=width, anchor="w", bg="white", fg=COLORS["text"],
                         padx=12, pady=15, font=("Yu Gothic UI", 9)).pack(side="left", fill="x", expand=True)


if __name__ == "__main__":
    app = OwlHRMock()
    app.mainloop()
